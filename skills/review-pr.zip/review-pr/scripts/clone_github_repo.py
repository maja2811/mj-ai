#!/usr/bin/env python3

from __future__ import annotations

import argparse
import json
import re
import shutil
import subprocess
import sys
import uuid
from pathlib import Path
from urllib.parse import urlparse


def eprint(message: str) -> None:
    print(message, file=sys.stderr)


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        description=(
            "Clone a GitHub repository into a review workspace so it can be "
            "inspected without leaving the current directory."
        )
    )
    parser.add_argument(
        "--repo",
        required=True,
        help="GitHub repo as owner/name or https://github.com/owner/name",
    )
    parser.add_argument(
        "--workspace",
        help=(
            "Workspace directory; defaults to a hidden local workspace "
            "under ./.review-pr-tmp"
        ),
    )
    parser.add_argument(
        "--ref",
        help="Optional branch, tag, or ref to clone",
    )
    parser.add_argument(
        "--directory-name",
        help="Optional directory name under <workspace>/reference-repos",
    )
    parser.add_argument(
        "--json",
        action="store_true",
        help="Print a JSON manifest to stdout",
    )
    return parser


def ensure_workspace(path_value: str | None) -> Path:
    if path_value:
        path = Path(path_value).expanduser().resolve()
        path.mkdir(parents=True, exist_ok=True)
        return path

    root = Path.cwd().resolve() / ".review-pr-tmp"
    root.mkdir(parents=True, exist_ok=True)

    while True:
        path = root / f"review-pr-reference-{uuid.uuid4().hex[:8]}"
        try:
            path.mkdir()
            return path
        except FileExistsError:
            continue


def parse_repo(repo_value: str) -> str:
    repo_value = repo_value.strip()
    parsed = urlparse(repo_value)

    if parsed.scheme in {"http", "https"}:
        if (parsed.netloc or "").lower() not in {"github.com", "www.github.com"}:
            raise SystemExit("Repo URL must point to github.com.")
        parts = [part for part in parsed.path.split("/") if part]
        if len(parts) < 2:
            raise SystemExit(
                "Repo URL must look like https://github.com/<owner>/<repo>."
            )
        owner = parts[0]
        repo = parts[1]
        if repo.endswith(".git"):
            repo = repo[:-4]
        return f"{owner}/{repo}"

    if re.fullmatch(r"[^/\s]+/[^/\s]+", repo_value):
        return repo_value

    raise SystemExit(
        "Repo must look like owner/repo or https://github.com/<owner>/<repo>."
    )


def require_gh() -> None:
    if shutil.which("gh") is None:
        raise SystemExit("GitHub CLI 'gh' is required for this script.")


def run_checked(command: list[str]) -> None:
    try:
        subprocess.run(command, check=True, text=True)
    except subprocess.CalledProcessError as exc:
        raise RuntimeError(
            f"Command failed with exit code {exc.returncode}: {' '.join(command)}"
        ) from exc


def slugify(value: str) -> str:
    lowered = value.strip().lower()
    slug = re.sub(r"[^a-z0-9]+", "-", lowered)
    return slug.strip("-") or "repo"


def main() -> int:
    args = build_parser().parse_args()
    require_gh()

    repo_full_name = parse_repo(args.repo)
    workspace = ensure_workspace(args.workspace)
    reference_root = workspace / "reference-repos"
    reference_root.mkdir(parents=True, exist_ok=True)

    directory_name = args.directory_name or slugify(repo_full_name)
    clone_path = reference_root / directory_name

    if clone_path.exists() and any(clone_path.iterdir()):
        raise SystemExit(f"Clone path already exists and is not empty: {clone_path}")

    command = [
        "gh",
        "repo",
        "clone",
        repo_full_name,
        str(clone_path),
        "--",
        "--depth",
        "1",
    ]
    if args.ref:
        command.extend(["--branch", args.ref, "--single-branch"])

    eprint(f"Workspace: {workspace}")
    eprint(f"Cloning {repo_full_name}")
    run_checked(command)

    manifest = {
        "workspace": str(workspace),
        "reference_root": str(reference_root),
        "repo_full_name": repo_full_name,
        "requested_ref": args.ref,
        "directory_name": directory_name,
        "clone_path": str(clone_path),
        "repo_url": f"https://github.com/{repo_full_name}",
    }

    if args.json:
        print(json.dumps(manifest, indent=2))
    else:
        for key, value in manifest.items():
            print(f"{key}: {value}")
    return 0


if __name__ == "__main__":
    try:
        raise SystemExit(main())
    except Exception as exc:
        eprint(str(exc))
        raise
