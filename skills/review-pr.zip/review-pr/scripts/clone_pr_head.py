#!/usr/bin/env python3

from __future__ import annotations

import argparse
import json
import os
import re
import shutil
import subprocess
import sys
import uuid
from pathlib import Path
from typing import Any
from urllib.parse import urlparse


def eprint(message: str) -> None:
    print(message, file=sys.stderr)


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        description=(
            "Clone the PR head branch into a workspace and save the PR metadata and diff."
        )
    )
    parser.add_argument("--pr-url", required=True, help="GitHub PR URL")
    parser.add_argument(
        "--workspace",
        help=(
            "Workspace directory; defaults to a hidden local workspace "
            "under ./.review-pr-tmp"
        ),
    )
    parser.add_argument(
        "--json",
        action="store_true",
        help="Print a JSON manifest to stdout",
    )
    return parser


def ensure_workspace(path_value: str | None) -> Path:
    if path_value:
        path = Path(path_value).expanduser().resolve()
        path.mkdir(parents=True, exist_ok=True)
        return path

    root = Path.cwd().resolve() / ".review-pr-tmp"
    root.mkdir(parents=True, exist_ok=True)

    while True:
        path = root / f"review-pr-clone-{uuid.uuid4().hex[:8]}"
        try:
            path.mkdir()
            return path
        except FileExistsError:
            continue


def parse_pr_url(pr_url: str) -> tuple[str, str, int]:
    parsed = urlparse(pr_url)
    if parsed.scheme not in {"http", "https"}:
        raise SystemExit("PR URL must use http or https.")
    if (parsed.netloc or "").lower() not in {"github.com", "www.github.com"}:
        raise SystemExit("PR URL must point to github.com.")

    parts = [part for part in parsed.path.split("/") if part]
    if len(parts) < 4 or parts[2] != "pull":
        raise SystemExit(
            "PR URL must look like https://github.com/<owner>/<repo>/pull/<number>."
        )

    try:
        number = int(parts[3])
    except ValueError as exc:
        raise SystemExit("PR number in URL is not valid.") from exc

    return parts[0], parts[1], number


def require_gh() -> None:
    if shutil.which("gh") is None:
        raise SystemExit("GitHub CLI 'gh' is required for this script.")


def run_gh_json(command: list[str], *, cwd: Path | None = None) -> Any:
    try:
        result = subprocess.run(
            command,
            cwd=cwd,
            check=True,
            capture_output=True,
            text=True,
        )
    except subprocess.CalledProcessError as exc:
        stderr = (exc.stderr or "").strip()
        stdout = (exc.stdout or "").strip()
        detail = stderr or stdout or f"exit code {exc.returncode}"
        raise RuntimeError(f"Command failed: {' '.join(command)}\n{detail}") from exc

    try:
        return json.loads(result.stdout)
    except json.JSONDecodeError as exc:
        raise RuntimeError(f"Expected JSON from command: {' '.join(command)}") from exc


def run_gh_capture(
    command: list[str], output_path: Path, *, cwd: Path | None = None
) -> None:
    try:
        result = subprocess.run(
            command,
            cwd=cwd,
            check=True,
            capture_output=True,
            text=True,
        )
    except subprocess.CalledProcessError as exc:
        stderr = (exc.stderr or "").strip()
        stdout = (exc.stdout or "").strip()
        detail = stderr or stdout or f"exit code {exc.returncode}"
        raise RuntimeError(f"Command failed: {' '.join(command)}\n{detail}") from exc

    output_path.write_text(result.stdout, encoding="utf-8")


def run_gh_clone(repo_full_name: str, branch: str, clone_path: Path) -> None:
    command = [
        "gh",
        "repo",
        "clone",
        repo_full_name,
        str(clone_path),
        "--",
        "--depth",
        "1",
        "--branch",
        branch,
        "--single-branch",
    ]
    try:
        subprocess.run(command, check=True, text=True)
    except subprocess.CalledProcessError as exc:
        raise RuntimeError(
            f"Failed to clone {repo_full_name}@{branch} (exit code {exc.returncode})."
        ) from exc


def slugify(value: str) -> str:
    lowered = value.strip().lower()
    slug = re.sub(r"[^a-z0-9]+", "-", lowered)
    return slug.strip("-") or "review"


def main() -> int:
    args = build_parser().parse_args()
    require_gh()

    owner, repo, number = parse_pr_url(args.pr_url)
    workspace = ensure_workspace(args.workspace)
    pr_json_path = workspace / "pr.json"
    diff_path = workspace / "pr.diff"
    clone_path = workspace / "clone"

    if clone_path.exists() and any(clone_path.iterdir()):
        raise SystemExit(f"Clone path already exists and is not empty: {clone_path}")

    eprint(f"Workspace: {workspace}")
    eprint(f"Fetching PR metadata for {owner}/{repo}#{number}")

    pr_data = run_gh_json(["gh", "api", f"repos/{owner}/{repo}/pulls/{number}"])
    pr_json_path.write_text(json.dumps(pr_data, indent=2), encoding="utf-8")

    head = pr_data.get("head") or {}
    base = pr_data.get("base") or {}
    head_repo = head.get("repo") or {}
    repo_full_name = head_repo.get("full_name")
    head_ref = head.get("ref")
    head_sha = head.get("sha")
    base_ref = base.get("ref")
    title = pr_data.get("title") or ""

    if not repo_full_name or not head_ref:
        raise RuntimeError(
            "PR metadata did not include a cloneable head repository and branch."
        )

    eprint(f"Cloning {repo_full_name}@{head_ref}")
    run_gh_clone(repo_full_name, head_ref, clone_path)

    eprint("Saving PR diff")
    run_gh_capture(["gh", "pr", "diff", args.pr_url], diff_path)

    suggested_filename = f"pr-review-{slugify(owner)}-{slugify(repo)}-{number}.md"

    manifest = {
        "workspace": str(workspace),
        "clone_path": str(clone_path),
        "pr_json_path": str(pr_json_path),
        "diff_path": str(diff_path),
        "owner": owner,
        "repo": repo,
        "number": number,
        "title": title,
        "pr_url": pr_data.get("html_url") or args.pr_url,
        "head_repo_full_name": repo_full_name,
        "head_ref": head_ref,
        "head_sha": head_sha,
        "base_ref": base_ref,
        "suggested_filename": suggested_filename,
    }

    if args.json:
        print(json.dumps(manifest, indent=2))
    else:
        for key, value in manifest.items():
            print(f"{key}: {value}")
    return 0


if __name__ == "__main__":
    try:
        raise SystemExit(main())
    except Exception as exc:
        eprint(str(exc))
        raise
