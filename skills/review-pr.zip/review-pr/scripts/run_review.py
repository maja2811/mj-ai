#!/usr/bin/env python3

from __future__ import annotations

import argparse
import atexit
import json
import os
import re
import shutil
import socket
import subprocess
import sys
import time
import urllib.error
import urllib.request
import uuid
from pathlib import Path
from typing import Any


def eprint(message: str) -> None:
    print(message, file=sys.stderr)


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        description=(
            "Start the PR reviewer backend on a random local port, run a review, "
            "capture the artifacts, and shut the backend down again."
        )
    )
    parser.add_argument("--pr-url", required=True, help="GitHub PR URL to review")
    parser.add_argument(
        "--backend-root",
        help="Path to the reviewer backend root containing app/main.py",
    )
    parser.add_argument(
        "--python-executable",
        help="Python executable for the backend environment",
    )
    parser.add_argument(
        "--workspace",
        help=(
            "Workspace directory for artifacts; defaults to a hidden local "
            "workspace under ./.review-pr-tmp"
        ),
    )
    parser.add_argument(
        "--startup-timeout",
        type=float,
        default=90.0,
        help="Seconds to wait for backend startup",
    )
    parser.add_argument(
        "--request-timeout",
        type=float,
        default=120.0,
        help="Seconds to wait for non-streaming HTTP requests",
    )
    parser.add_argument(
        "--json",
        action="store_true",
        help="Print a JSON manifest to stdout",
    )

    parser.add_argument("--model-key")
    parser.add_argument("--max-tokens", type=int)
    parser.add_argument("--prompt")
    parser.add_argument("--reasoning-effort")
    parser.add_argument("--thinking-level", type=int)
    parser.add_argument(
        "--excluded-file",
        action="append",
        dest="excluded_files",
        help="Repeat for each excluded file",
    )
    parser.add_argument(
        "--clear-excluded-files",
        action="store_true",
        help="Send an explicit empty excluded_files list",
    )
    parser.add_argument(
        "--enable-agent-tools",
        action=argparse.BooleanOptionalAction,
        default=None,
    )
    parser.add_argument(
        "--enable-ci-checks",
        action=argparse.BooleanOptionalAction,
        default=None,
    )
    parser.add_argument(
        "--enable-validation",
        action=argparse.BooleanOptionalAction,
        default=None,
    )
    parser.add_argument(
        "--enable-final-review",
        action=argparse.BooleanOptionalAction,
        default=None,
    )
    parser.add_argument(
        "--focus-changed-only",
        action=argparse.BooleanOptionalAction,
        default=None,
    )
    parser.add_argument("--checklist-url")
    parser.add_argument("--custom-instruction")
    parser.add_argument("--temperature", type=float)
    parser.add_argument(
        "--force-initial-review",
        action=argparse.BooleanOptionalAction,
        default=None,
    )
    parser.add_argument("--model-id")
    parser.add_argument("--max-tokens-setting", type=int)
    return parser


def is_backend_root(path: Path) -> bool:
    return (
        path.is_dir()
        and (path / "app" / "main.py").is_file()
        and (path / "requirements.txt").is_file()
    )


def unique_paths(paths: list[Path]) -> list[Path]:
    seen: set[str] = set()
    ordered: list[Path] = []
    for path in paths:
        key = str(path)
        if key in seen:
            continue
        seen.add(key)
        ordered.append(path)
    return ordered


def discover_backend_root(explicit: str | None) -> Path:
    candidates: list[Path] = []
    if explicit:
        candidates.append(Path(explicit).expanduser())

    env_root = os.getenv("PR_REVIEWER_BACKEND_ROOT")
    if env_root:
        candidates.append(Path(env_root).expanduser())

    cwd = Path.cwd().resolve()
    for base in [cwd, *cwd.parents[:6]]:
        candidates.append(base / "backend")
        candidates.append(base / "pr_reviewer_app" / "backend")

    # Check sibling directories of cwd's parent (common workspace layout where
    # all repos live under the same folder, e.g. ~/work/)
    workspace_dir = cwd.parent
    if workspace_dir.exists():
        reviewer_dir = workspace_dir / "bi-dlh-pr-reviewer"
        if reviewer_dir.is_dir():
            candidates.append(reviewer_dir / "backend")
            candidates.append(reviewer_dir / "pr_reviewer_app" / "backend")

    for candidate in unique_paths(candidates):
        if is_backend_root(candidate):
            return candidate.resolve()

    raise SystemExit(
        "Could not locate the reviewer backend. Pass --backend-root or set PR_REVIEWER_BACKEND_ROOT."
    )


def command_exists(command: str) -> bool:
    return shutil.which(command) is not None


def discover_python(explicit: str | None, backend_root: Path) -> str:
    candidates: list[str] = []
    if explicit:
        candidates.append(explicit)

    env_python = os.getenv("PR_REVIEWER_PYTHON")
    if env_python:
        candidates.append(env_python)

    for base in (backend_root, backend_root.parent, backend_root.parent.parent):
        if sys.platform == "win32":
            candidates.append(str(base / ".venv" / "Scripts" / "python.exe"))
        else:
            candidates.append(str(base / ".venv" / "bin" / "python"))

    candidates.append(sys.executable)
    if sys.platform == "win32":
        candidates.append("python")
    else:
        candidates.append("python3")

    seen: set[str] = set()
    for candidate in candidates:
        if candidate in seen:
            continue
        seen.add(candidate)

        executable = candidate
        if os.sep not in candidate and not command_exists(candidate):
            continue
        if os.sep in candidate and not Path(candidate).exists():
            continue

        try:
            subprocess.run(
                [executable, "-c", "import uvicorn"],
                check=True,
                stdout=subprocess.DEVNULL,
                stderr=subprocess.DEVNULL,
            )
            return executable
        except Exception:
            continue

    raise SystemExit(
        "Could not find a Python executable with uvicorn installed. Pass --python-executable or set PR_REVIEWER_PYTHON."
    )


def ensure_workspace(path_value: str | None) -> Path:
    if path_value:
        path = Path(path_value).expanduser().resolve()
        path.mkdir(parents=True, exist_ok=True)
        return path

    root = Path.cwd().resolve() / ".review-pr-tmp"
    root.mkdir(parents=True, exist_ok=True)

    while True:
        path = root / f"review-pr-{uuid.uuid4().hex[:8]}"
        try:
            path.mkdir()
            return path
        except FileExistsError:
            continue


def find_free_port() -> int:
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as sock:
        sock.bind(("127.0.0.1", 0))
        sock.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
        return int(sock.getsockname()[1])


def tail_text(path: Path, max_lines: int = 40) -> str:
    if not path.exists():
        return ""
    lines = path.read_text(encoding="utf-8", errors="replace").splitlines()
    return "\n".join(lines[-max_lines:])


def run_checked(
    command: list[str], *, cwd: Path, env: dict[str, str], description: str
) -> None:
    try:
        subprocess.run(command, cwd=cwd, env=env, check=True)
    except subprocess.CalledProcessError as exc:
        raise RuntimeError(
            f"{description} failed with exit code {exc.returncode}"
        ) from exc


def create_database(
    python_executable: str, backend_root: Path, env: dict[str, str]
) -> None:
    command = [
        python_executable,
        "-c",
        (
            "from models.db_models import Base; "
            "from core.db import engine; "
            "Base.metadata.create_all(bind=engine)"
        ),
    ]
    run_checked(
        command, cwd=backend_root, env=env, description="Database initialization"
    )


def wait_for_server(
    base_url: str,
    process: subprocess.Popen[str],
    log_path: Path,
    timeout_seconds: float,
) -> None:
    deadline = time.time() + timeout_seconds
    health_url = f"{base_url}/api/config/flags"
    last_error = ""

    while time.time() < deadline:
        if process.poll() is not None:
            log_tail = tail_text(log_path)
            raise RuntimeError(
                "Reviewer backend exited during startup."
                + (f"\n\nBackend log tail:\n{log_tail}" if log_tail else "")
            )

        try:
            request_json(health_url, timeout=2.0)
            return
        except Exception as exc:
            last_error = str(exc)
            time.sleep(0.5)

    log_tail = tail_text(log_path)
    raise RuntimeError(
        f"Timed out waiting for reviewer backend startup. Last error: {last_error}"
        + (f"\n\nBackend log tail:\n{log_tail}" if log_tail else "")
    )


def request_json(
    url: str,
    *,
    method: str = "GET",
    payload: dict[str, Any] | None = None,
    timeout: float = 120.0,
) -> Any:
    data: bytes | None = None
    headers: dict[str, str] = {"Accept": "application/json"}
    if payload is not None:
        data = json.dumps(payload).encode("utf-8")
        headers["Content-Type"] = "application/json"

    request = urllib.request.Request(url, data=data, headers=headers, method=method)
    try:
        with urllib.request.urlopen(request, timeout=timeout) as response:
            return json.loads(response.read().decode("utf-8"))
    except urllib.error.HTTPError as exc:
        body = exc.read().decode("utf-8", errors="replace")
        raise RuntimeError(f"HTTP {exc.code} from {url}: {body}") from exc
    except urllib.error.URLError as exc:
        raise RuntimeError(f"Request to {url} failed: {exc}") from exc


def stream_events(url: str, output_path: Path) -> int:
    request = urllib.request.Request(
        url, headers={"Accept": "text/event-stream"}, method="GET"
    )
    event_count = 0
    saw_done = False

    try:
        with output_path.open("w", encoding="utf-8") as handle:
            with urllib.request.urlopen(request) as response:
                for raw_line in response:
                    line = raw_line.decode("utf-8", errors="replace").rstrip("\r\n")
                    if not line.startswith("data: "):
                        continue
                    payload_text = line[6:]
                    event = json.loads(payload_text)
                    handle.write(json.dumps(event, ensure_ascii=False) + "\n")
                    handle.flush()
                    event_count += 1
                    if event.get("type") == "done":
                        saw_done = True
                        break
    except urllib.error.HTTPError as exc:
        body = exc.read().decode("utf-8", errors="replace")
        raise RuntimeError(f"Streaming failed with HTTP {exc.code}: {body}") from exc
    except urllib.error.URLError as exc:
        raise RuntimeError(f"Streaming request failed: {exc}") from exc

    if not saw_done:
        raise RuntimeError("Review stream ended without a done event.")

    return event_count


def extract_prompt_text(history: dict[str, Any]) -> str | None:
    conversation = history.get("conversation") or []
    for turn in conversation:
        if turn.get("role") != "user":
            continue
        content = turn.get("content")
        if isinstance(content, str) and content:
            return content
    return None


def extract_ci_checks(prompt_text: str | None) -> str | None:
    if not prompt_text:
        return None

    patterns = (
        re.compile(r"<ci_checks>\s*<!\[CDATA\[(.*?)\]\]>\s*</ci_checks>", re.DOTALL),
        re.compile(r"<ci_checks>\s*(.*?)\s*</ci_checks>", re.DOTALL),
    )

    for pattern in patterns:
        match = pattern.search(prompt_text)
        if not match:
            continue
        ci_text = match.group(1).strip()
        if ci_text:
            return ci_text
    return None


def extract_review_artifacts(
    history: dict[str, Any],
) -> tuple[str, str, str | None, int]:
    conversation = history.get("conversation") or []
    assistant_turns = [
        turn.get("content", "")
        for turn in conversation
        if turn.get("role") == "assistant" and isinstance(turn.get("content"), str)
    ]
    review_turns = [
        text
        for text in assistant_turns
        if text and not text.lstrip().startswith("## Validation Report")
    ]
    validation_report = next(
        (
            text
            for text in reversed(assistant_turns)
            if text.lstrip().startswith("## Validation Report")
        ),
        None,
    )

    if review_turns:
        return (
            review_turns[0],
            review_turns[-1],
            validation_report,
            len(assistant_turns),
        )

    raise RuntimeError("Review history did not contain any assistant output.")


def build_payload(args: argparse.Namespace) -> dict[str, Any]:
    if args.clear_excluded_files and args.excluded_files:
        raise SystemExit(
            "Use either --clear-excluded-files or --excluded-file, not both."
        )

    payload: dict[str, Any] = {"pr_url": args.pr_url}

    optional_fields = {
        "model_key": args.model_key,
        "max_tokens": args.max_tokens,
        "prompt": args.prompt,
        "reasoning_effort": args.reasoning_effort,
        "thinking_level": args.thinking_level,
        "enable_agent_tools": args.enable_agent_tools,
        "enable_ci_checks": args.enable_ci_checks,
        "enable_validation": args.enable_validation,
        "enable_final_review": args.enable_final_review,
        "focus_changed_only": args.focus_changed_only,
        "checklist_url": args.checklist_url,
        "custom_instruction": args.custom_instruction,
        "temperature": args.temperature,
        "force_initial_review": args.force_initial_review,
        "model_id": args.model_id,
        "max_tokens_setting": args.max_tokens_setting,
    }

    for key, value in optional_fields.items():
        if value is not None:
            payload[key] = value

    if args.clear_excluded_files:
        payload["excluded_files"] = []
    elif args.excluded_files:
        payload["excluded_files"] = args.excluded_files

    return payload


def terminate_process(process: subprocess.Popen[str] | None) -> None:
    if process is None or process.poll() is not None:
        return
    process.terminate()
    try:
        process.wait(timeout=10)
    except subprocess.TimeoutExpired:
        process.kill()
        process.wait(timeout=5)


def main() -> int:
    args = build_parser().parse_args()
    workspace = ensure_workspace(args.workspace)
    backend_root = discover_backend_root(args.backend_root)
    python_executable = discover_python(args.python_executable, backend_root)

    payload = build_payload(args)
    payload_path = workspace / "request_payload.json"
    start_response_path = workspace / "start_response.json"
    stream_events_path = workspace / "stream_events.jsonl"
    history_path = workspace / "history.json"
    prompt_path = workspace / "review_prompt.xml"
    ci_checks_path = workspace / "ci_checks.txt"
    raw_review_path = workspace / "raw_review.md"
    initial_review_path = workspace / "initial_review.md"
    final_review_path = workspace / "final_review.md"
    validation_report_path = workspace / "validation_report.md"
    log_path = workspace / "backend.log"
    db_path = workspace / "pr_reviewer.db"

    env = os.environ.copy()
    env["DATABASE_URL"] = f"sqlite:///{db_path}"
    env["PYTHONUNBUFFERED"] = "1"

    payload_path.write_text(json.dumps(payload, indent=2), encoding="utf-8")

    eprint(f"Workspace: {workspace}")
    eprint(f"Backend root: {backend_root}")
    eprint(f"Python executable: {python_executable}")

    create_database(python_executable, backend_root, env)

    port = find_free_port()
    base_url = f"http://127.0.0.1:{port}"
    server_process: subprocess.Popen[str] | None = None

    with log_path.open("w", encoding="utf-8") as log_handle:
        server_process = subprocess.Popen(
            [
                python_executable,
                "-m",
                "uvicorn",
                "app.main:app",
                "--host",
                "127.0.0.1",
                "--port",
                str(port),
            ],
            cwd=backend_root,
            env=env,
            stdout=log_handle,
            stderr=subprocess.STDOUT,
            text=True,
        )

        atexit.register(terminate_process, server_process)

        try:
            wait_for_server(base_url, server_process, log_path, args.startup_timeout)
            eprint(f"Reviewer backend is ready on {base_url}")

            start_response = request_json(
                f"{base_url}/api/review/start",
                method="POST",
                payload=payload,
                timeout=args.request_timeout,
            )
            start_response_path.write_text(
                json.dumps(start_response, indent=2), encoding="utf-8"
            )

            session_id = str(start_response["session_id"])
            eprint(f"Review session: {session_id}")

            event_count = stream_events(
                f"{base_url}/api/review/stream/{session_id}", stream_events_path
            )
            eprint(f"Captured {event_count} stream events")

            history = request_json(
                f"{base_url}/api/review/history/{session_id}",
                timeout=args.request_timeout,
            )
            history_path.write_text(json.dumps(history, indent=2), encoding="utf-8")

            prompt_text = extract_prompt_text(history)
            prompt_path_value: str | None = None
            if prompt_text:
                prompt_path.write_text(prompt_text, encoding="utf-8")
                prompt_path_value = str(prompt_path)

            ci_checks_text = extract_ci_checks(prompt_text)
            ci_checks_path_value: str | None = None
            if ci_checks_text:
                ci_checks_path.write_text(ci_checks_text, encoding="utf-8")
                ci_checks_path_value = str(ci_checks_path)

            initial_review, final_review, validation_report, assistant_turn_count = (
                extract_review_artifacts(history)
            )
            raw_review_path.write_text(initial_review, encoding="utf-8")
            initial_review_path.write_text(initial_review, encoding="utf-8")
            final_review_path.write_text(final_review, encoding="utf-8")

            validation_path_value: str | None = None
            if validation_report:
                validation_report_path.write_text(validation_report, encoding="utf-8")
                validation_path_value = str(validation_report_path)

            manifest = {
                "workspace": str(workspace),
                "backend_root": str(backend_root),
                "python_executable": python_executable,
                "port": port,
                "base_url": base_url,
                "db_path": str(db_path),
                "log_path": str(log_path),
                "request_payload_path": str(payload_path),
                "start_response_path": str(start_response_path),
                "stream_events_path": str(stream_events_path),
                "history_path": str(history_path),
                "prompt_path": prompt_path_value,
                "ci_checks_path": ci_checks_path_value,
                "raw_review_path": str(raw_review_path),
                "initial_review_path": str(initial_review_path),
                "final_review_path": str(final_review_path),
                "review_path": str(final_review_path),
                "validation_report_path": validation_path_value,
                "session_id": session_id,
                "assistant_turn_count": assistant_turn_count,
                "stream_event_count": event_count,
            }

            if args.json:
                print(json.dumps(manifest, indent=2))
            else:
                for key, value in manifest.items():
                    print(f"{key}: {value}")
            return 0
        finally:
            terminate_process(server_process)


if __name__ == "__main__":
    try:
        raise SystemExit(main())
    except Exception as exc:
        eprint(str(exc))
        raise
