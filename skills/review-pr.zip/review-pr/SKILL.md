---
name: review-pr
description: Run the local PR reviewer against a GitHub pull request URL, then audit the generated review against the PR diff and a cloned copy of the PR head branch before producing a final markdown file. Use this skill whenever the user asks to run the in-house reviewer for a PR URL, generate a markdown PR review, validate or correct reviewer output, or review a GitHub PR with explicit model / checklist / CI / tool / exclusion options. Support the full `/api/review/start` option set when the user mentions it, and otherwise keep backend defaults by omitting unspecified options.
compatibility: Requires Python 3, GitHub CLI (`gh`) authenticated for the target repositories, network access to GitHub, and a local checkout of the PR reviewer backend discoverable from the workspace or `PR_REVIEWER_BACKEND_ROOT`. If runtime validation needs Databricks execution, it also requires Databricks CLI (`databricks`) plus a Databricks profile that the agent authenticates or verifies through the CLI before use, with permission to run read-only SQL queries and, when needed, temporary notebook or one-time job probes.
---

# Review PR

This skill runs the existing FastAPI reviewer backend, captures the generated review, clones the PR head branch into a workspace-local hidden temp folder, and audits the review for correctness before writing the final markdown file.

Before writing or reviewing code, always read `checklist.md` from the repo root when it exists.
If the repo does not contain a local `checklist.md`, use the template checklist at
`https://github.com/DanskeStatsbaner/bi-dlh-project-template/blob/main/checklist.md`.
Treat whichever source is available as the checklist source of truth for that review.

The important part is the second pass: do not trust the raw reviewer output. The deliverable is the corrected markdown review, not the first draft.

## Resolve Uncertainty Actively

If anything important is unclear, do not default to a weaker or vaguer answer until you have tried to resolve the uncertainty.

- Use the available tools, helper scripts, GitHub metadata, cloned repo, backend artifacts, and relevant supporting skills to find a concrete answer.
- Prefer investigating over hedging when the answer is likely recoverable from evidence.
- Escalate to the user only when the missing information cannot reasonably be recovered from the available tools or repositories.
- If a point remains uncertain after investigation, make the uncertainty specific and narrow instead of letting it blur the whole review.

## Databricks-Backed Runtime Validation

When a claim depends on actual Databricks runtime behavior and static repo evidence is not enough, prefer Databricks-backed execution over local Spark.

This applies especially to:

- Spark SQL parsing, casting, coercion, and ANSI-mode behavior
- DataFrame or PySpark semantics that are runtime-dependent
- notebook/widget parameter behavior
- cluster/runtime environment differences that cannot be settled from config alone
- Databricks-specific behavior where local Spark could differ materially

Rules:

- Load the `databricks` skill before running Databricks commands.
- The agent is responsible for handling Databricks CLI authentication when runtime validation needs it. Do not offload the whole authentication task to the user if it can be completed through the CLI flow.
- Never auto-select a Databricks profile.
- If the user explicitly provided a Databricks profile, use it.
- Otherwise, run `databricks auth profiles`, show the available profiles, and ask the user to choose one before any Databricks execution.
- If the chosen profile is missing or invalid, the agent must drive the Databricks CLI authentication workflow itself by following the `databricks` skill and running `databricks auth login --host <workspace-url> --profile <profile-name>`.
- Ask the user only for the pieces the CLI flow cannot safely infer, such as which workspace URL to use or what profile name they want for a new login.
- After authentication, verify the chosen profile with a lightweight Databricks CLI command before using it for runtime validation.
- Prefer the least invasive probe that can answer the question:
  - For SQL-expression or warehouse-readable behavior, use `databricks experimental aitools tools query`.
  - For PySpark/DataFrame/notebook behavior that cannot be validated in SQL alone, use a temporary notebook imported into the selected user's Databricks workspace and run it with a one-time Databricks job.
- Use `databricks current-user me --profile <profile>` to determine the selected user's workspace path before importing temporary notebooks.
- Save all Databricks command inputs and outputs under `<WORKSPACE>/databricks-validation/`.
- Prefer literals, temp views, and read-only queries over real data mutations.
- Never mutate production tables, volumes, jobs, secrets, or deployed workspace assets just to validate a review claim.
- Never treat local `spark-sql`, local `pyspark`, or a mismatched local Spark install as authoritative for Databricks-targeted behavior when Databricks execution is feasible.
- Delete temporary Databricks workspace paths after capturing the evidence.
- If Databricks execution is needed but cannot be performed safely, say exactly what blocked it and keep the claim narrower.
- If Databricks authentication requires browser interaction, trigger the CLI login flow and guide the user through the browser step only as needed; do not stop at "please authenticate Databricks" without first initiating the proper CLI workflow.

Bundled scripts:

- `scripts/run_review.py` starts the backend on a random local port, prepares a local SQLite database inside the review workspace, runs the review through the API, captures the stream/history artifacts, and shuts the backend down again.
- `scripts/clone_pr_head.py` fetches PR metadata with `gh`, clones the PR head branch into the local review workspace, and saves the PR diff.
- `scripts/clone_github_repo.py` clones supporting GitHub repositories into the same local review workspace under `reference-repos/`.

## Non-Negotiable Backend Alignment

- Use the reviewer backend's own severity vocabulary exactly: `CRITICAL`, `MAJOR`, `MINOR`, `SUGGESTION`.
- Never invent alternative severities such as `HIGH`, `MEDIUM`, `LOW`, `INFO`, or similar.
- Treat the backend's final review, validation report, prompt, and extracted CI checks as first-class evidence, because they already reflect the reviewer implementation and Azure DevOps integration.
- Do not replace backend CI evidence with weaker GitHub status inference when the backend artifacts contain the exact CI details.
- Do not assume the backend final review is exhaustive. It is the starting point, not the ceiling.

## When To Use This Skill

Use this skill when the user asks to:

- run the reviewer for a GitHub PR URL
- generate a markdown PR review file from the in-house reviewer
- review a PR with specific reviewer settings like model, checklist, exclusions, CI, validation, or final-pass flags
- validate or correct reviewer output against the actual branch contents

If the task is only to inspect the backend code or discuss reviewer architecture, this skill is not needed.

## Default Workflow

### 1. Require a PR URL

- If the user did not provide a PR URL, ask for it.
- If multiple PR URLs are mentioned and the intended one is ambiguous, ask which PR to review.

### 2. Extract only explicit review options

Translate only the options the user explicitly asked for.

- If the user does not mention an option, omit that flag entirely so the backend default is used.
- Do not invent model names, checklist URLs, exclusions, or boolean settings.
- If the user explicitly asks for defaults, omit the corresponding flags even if they mentioned the option category.
- If the user explicitly provides a Databricks profile for runtime validation, use it later instead of asking again.
- If the user explicitly provides a Databricks workspace URL and/or preferred profile name, use those values when authenticating through the Databricks CLI.
- If the user explicitly says not to execute code or not to use Databricks, respect that and do not perform Databricks-backed validation.

### 3. Choose paths

- Create a workspace-local hidden review folder under `./.review-pr-tmp/`.
- Prefer a per-run directory like `./.review-pr-tmp/review-pr-<id>/`.
- Keep all review artifacts, the PR clone, and any supporting source-of-truth repo clones under that same workspace so the run stays inside the current directory.
- If the user gave an output path, use it.
- Otherwise, after cloning the PR metadata, default the final file to `./pr-review-<owner>-<repo>-<number>.md`.

### 4. Run the raw reviewer

Use the helper script and write its manifest to the workspace.

```bash
python ~/.config/opencode/skills/review-pr/scripts/run_review.py \
  --pr-url "<PR_URL>" \
  --workspace "<WORKSPACE>" \
  --json > "<WORKSPACE>/reviewer-manifest.json"
```

Append only the flags the user actually requested.

After the script finishes, read `reviewer-manifest.json`, then inspect:

- `review_path` or `final_review_path` first
- `validation_report_path`
- `ci_checks_path`
- `prompt_path`
- `raw_review_path`
- `initial_review_path`
- `history_path`
- `stream_events_path`
- `log_path` if something failed

Artifact meaning:

- `final_review_path` / `review_path`: the backend's final validated review after its own validation/final passes. Use this as the base document for any correction pass.
- `validation_report_path`: the backend's explicit validation of the initial review.
- `ci_checks_path`: the Azure DevOps CI block extracted from the backend prompt. This can contain the exact mypy / ruff / format errors already retrieved by the reviewer.
- `prompt_path`: the full prompt sent to the backend model, including embedded PR description, discussion history, CI, and checklist context.
- `initial_review_path` / `raw_review_path`: the backend's first review draft before validation/final rewriting.

### 5. Clone the PR head branch and save the diff

```bash
python ~/.config/opencode/skills/review-pr/scripts/clone_pr_head.py \
  --pr-url "<PR_URL>" \
  --workspace "<WORKSPACE>" \
  --json > "<WORKSPACE>/pr-manifest.json"
```

After the script finishes, read `pr-manifest.json`, then inspect:

- `clone_path`
- `diff_path`
- `pr_json_path`
- `suggested_filename`

### 6. Audit the review for correctness and missed issues

Start from the backend final review markdown, not from a free-form rewrite. Verify its claims against the saved diff, the cloned branch, and the backend's own CI artifacts.

Do not treat the PR body or comment thread as fluff. They can contain business intent, rollout constraints, known limitations, rebuttals, environment assumptions, and reviewer/author clarifications that materially change whether a finding is correct, overstated, or already addressed.

The audit has two equally important goals:

1. correct anything in the backend review that is inaccurate, overstated, or incomplete
2. catch material issues the backend review missed

Audit precedence:

1. `final_review_path` / `review_path`
2. `validation_report_path`
3. `prompt_path` for PR description and discussion context
4. `ci_checks_path`
5. `pr.diff`
6. the cloned branch contents
7. Databricks runtime evidence, if collected
8. `history.json` / `stream_events.jsonl` only when additional backend evidence is needed

When the backend already provides exact CI text in `ci_checks_path`, treat that as authoritative reviewer evidence. Do not downgrade to generic GitHub status observations unless the backend artifacts are missing or internally inconsistent.

Audit in this order:

1. Read the backend final review and identify each concrete claim or finding.
2. Read the validation report to see what the backend itself believed it validated.
3. Read `prompt_path` and extract the PR description plus discussion history so you understand the stated intent, constraints, prior reviewer concerns, and author clarifications.
4. Read `ci_checks.txt` if present to confirm the exact CI error text before questioning a CI-backed finding.
5. Read `pr.diff` to understand the changed files and hunks.
6. Use targeted `Read` and `Grep` calls inside the cloned branch to verify code claims and cited call sites.
7. Check whether the PR description or discussion thread changes the interpretation of a finding, for example by documenting intentional scope, rollout guards, environment limitations, or already-accepted tradeoffs.
8. Treat author comments as evidence about intent and constraints, but not as proof that code is correct. Confirm any important claim against code, CI, docs, or runtime evidence before relying on it.
9. Treat reviewer comments and review summaries as important context for missed issues, prior objections, and areas needing verification, but do not keep a finding just because another reviewer said it.
10. If a claim depends on actual Databricks runtime semantics and static evidence is not enough, prefer Databricks-backed execution over local Spark or docs-only inference.
11. If the PR relies on package behavior, imports external/internal packages, upgrades or pins dependencies, or if a finding depends on how a package actually works, inspect the package's source-of-truth repository on GitHub before concluding.
12. Clone supporting source-of-truth repositories into `<WORKSPACE>/reference-repos/` instead of cloning them elsewhere on disk. Use `scripts/clone_github_repo.py` when you need a local checkout.
13. If the PR uses or upgrades `dlh-dmt-helper`, inspect the source of truth in `https://github.com/DanskeStatsbaner/bi-dlh-helper` so you can verify whether the package is being used correctly and whether newer package capabilities should be adopted.
14. If the PR touches or depends on platform behavior, deployment wiring, runtime configuration, environment-variable injection, cluster/job semantics, or documented platform conventions, inspect the source of truth in `https://github.com/DanskeStatsbaner/bi-dlh-documentation` and `https://github.com/DanskeStatsbaner/bi-dlh-dmt-ci-cd`.
15. When local inspection is helpful, clone those repos into the current review workspace instead of relying on external folders.
16. Check whether each existing finding is supported, overstated, incomplete, or wrong.
17. Perform a missed-issues sweep across the changed hunks, nearby context, PR description, discussion thread, CI artifacts, package source repos, platform documentation, deployment implementation, and Databricks runtime evidence to identify issues the backend review did not mention.

When PR description or discussion context is relevant:

- Use the PR description to understand claimed intent, rollout plan, scope boundaries, acceptance criteria, linked incidents, and any explicitly stated non-goals.
- Use discussion history to identify reviewer objections, author clarifications, deferred work, environment constraints, and places where the backend review may have missed a later correction.
- If the PR description or comments claim a behavior change is safe, verify that claim against code and runtime evidence before repeating it.
- If the PR description or comments explain why something is intentionally out of scope, do not turn that into a false-positive finding unless the out-of-scope decision still creates a concrete merge-blocking risk in the current diff.
- If a prior comment thread already identified an issue that is still unresolved in the code, you may keep or add that finding, but anchor it in the current code and evidence rather than quoting the comment alone.
- If comments reveal that a finding was already addressed in a later commit or clarified away, reflect that in the final review instead of preserving a stale objection.

When Databricks-backed execution is relevant:

- Use Databricks execution only when it materially increases certainty on a runtime-dependent claim.
- Before using a Databricks profile, verify it with the CLI. If it is invalid or missing, authenticate it through the CLI flow instead of silently abandoning Databricks validation.
- Prefer a Databricks SQL probe first for questions that can be answered by SQL alone, for example parser behavior, built-in function semantics, ANSI-sensitive casts, and read-only table checks.
- If SQL is not enough, create a small temporary notebook that reproduces only the disputed behavior and run it as a one-time Databricks job.
- Prefer existing dev/test workspace resources, repo-defined dev targets, or repo-defined non-production compute settings over inventing arbitrary cluster settings.
- If the repo or bundle defines relevant Spark versions, cluster policies, or job-cluster settings, reuse the closest safe non-production settings so the probe matches the reviewed runtime as closely as practical.
- Capture the exact query text, notebook source, run request, run output, and any relevant cluster/runtime metadata in `<WORKSPACE>/databricks-validation/`.
- If the runtime result depends on ANSI mode, session config, warehouse type, or runtime version, record those details and reflect them in the finding wording.
- If the safest available Databricks probe would still require writing production data or using unsafe resources, stop short of execution and keep the claim limited to what static evidence supports.

When package behavior is relevant:

- Treat the package's GitHub repository as the authoritative source for package APIs, signatures, supported usage patterns, changelog, tests, and versioned behavior.
- Use package source repos whenever a finding depends on whether the project is using a dependency correctly, whether a dependency upgrade requires code changes, whether a newer package capability should be adopted, or whether a package default/behavior actually changed.
- When cloning a package source repo for inspection, clone it inside the current review workspace under `reference-repos/`.
- Prefer package source, tags, changelogs, tests, packaged version metadata, and official package docs over guessing from local call names or examples.
- If the package is internal, proactively look for its GitHub repository under the relevant org before concluding the answer is unavailable. Example: `dlh-oracle` -> `https://github.com/DanskeStatsbaner/bi-dlh-oracle`.
- Determine the latest available package version from repo evidence before making a version recommendation.
- Encourage the latest available package version by default unless there is concrete evidence for incompatibility, intentional deferral, migration constraints, or a repo-local reason to stay behind.
- Distinguish carefully between package-source facts and repo-level impact. A package behavior change justifies a finding only when you can connect it to the reviewed repo's actual usage, operational flow, deployment path, or documented expectations.

When `dlh-dmt-helper` is relevant:

- Treat `bi-dlh-helper` as the authoritative source for package APIs, signatures, and supported usage patterns.
- Inspect the helper repo when the reviewed PR imports, calls, upgrades, pins, or could benefit from `dlh-dmt-helper` functionality.
- If you need a local checkout of the helper repo, clone it into the current review workspace under `reference-repos/bi-dlh-helper/`.
- Use the helper repo to verify whether a call site is correct, whether the PR is missing required adaptation for a version bump, and whether the code should lean on helper functionality more than it currently does.
- Prefer concrete evidence from helper source, release notes, docs, or version metadata over guessing from call names.
- Determine the latest available helper version from helper-repo evidence such as tags, changelog, packaged version metadata, or release notes before making a version recommendation.
- Encourage the latest available `dlh-dmt-helper` version by default. Only soften that recommendation when there is concrete evidence that the latest version is incompatible, intentionally deferred, or blocked by another dependency or migration constraint.
- If the PR intentionally stays on an older helper version, call that out as a recommendation unless the repo or PR context already explains why.
- Distinguish carefully between helper-source facts and repo-level impact. A helper change can justify a finding only when you can connect it to the reviewed repo's actual usage, operational flow, or documented expectations.

When platform behavior is relevant:

- Treat `bi-dlh-documentation` as the authoritative source for documented platform conventions, expected deployment patterns, and team guidance.
- Treat `bi-dlh-dmt-ci-cd` as the authoritative source for actual deployment and runtime wiring, including job/task parameters, cluster environment variables, and Databricks deployment behavior.
- Inspect those repos whenever a finding depends on how notebooks receive configuration, how jobs are deployed, what environment variables exist at runtime, how schemas/catalogs/volumes are provisioned, or what the documented platform contract is.
- If you need local checkouts of those repos, clone them into the current review workspace under `reference-repos/`.
- Prefer concrete evidence from platform docs and CI/CD implementation over guessing from repo-local YAML or notebook code in isolation.
- If the reviewed repo appears to conflict with the documented or implemented platform behavior, explain the conflict concretely in the final review.
- If the conflict still depends on runtime semantics after static inspection, validate the smallest reproducible part in Databricks rather than relying on local Spark.

Missed-issues sweep:

- Review the changed files directly, not just the backend findings table.
- Look for correctness, CI/CD, security, performance, maintainability, and project-convention issues that are actually evidenced by the diff and nearby code.
- Treat `ci_checks.txt` as a source of additional missed findings, not only as support for existing ones.
- Treat the PR description and discussion history as sources of additional missed issues, hidden constraints, and stale findings that need correction.
- Treat Databricks runtime probes as a source of additional missed findings when execution was needed to settle runtime behavior.
- If package behavior is relevant, also look for missed issues that only become visible when the reviewed repo is compared with the dependency's source repo.
- If `dlh-dmt-helper` is involved, also look for missed opportunities to adopt the helper correctly or more completely when the helper repo shows that a more current or better-supported pattern exists.
- If platform behavior is relevant, also look for missed issues that only become visible when the reviewed repo is compared with `bi-dlh-documentation` and `bi-dlh-dmt-ci-cd`.
- If the backend review missed a concrete CI failure, failing call site, wrong file reference, or another evidenced problem, add it to the final review seamlessly in the existing structure.
- Do not add speculative findings based only on absence of evidence.
- Keep an internal finding ledger while you audit. Every candidate missed issue must end in exactly one state: `kept` or `rejected`, with a short evidence-based reason.

Be especially skeptical about:

- wrong file or symbol names
- claims about behavior that the code does not actually implement
- findings that ignore nearby guards, validation, or existing tests
- severity that is not justified by the code
- statements about CI, configuration, or runtime behavior that are not evidenced in the repo
- statements about PR intent, business constraints, or rollout assumptions that are not evidenced in the PR description, discussion history, code, or linked docs
- statements about Spark or Databricks runtime semantics that are inferred from local Spark wrappers or a mismatched local runtime when Databricks execution was feasible
- remediation examples or migration notes that invent replacement APIs, parameter names, or implementation details not evidenced by the repo or backend artifacts
- package-repo discoveries that are true in the package but not yet tied concretely to the reviewed repo's behavior, expectations, version pin, or deployment path
- helper-repo discoveries that are true in the package but not yet tied concretely to the reviewed repo's behavior, expectations, or deployment path
- platform-doc or CI/CD-repo discoveries that are true in general but not yet tied concretely to the reviewed repo's deployment/runtime path

But also be careful not to discard true backend evidence just because it is not visible in the GitHub UI. If the backend already fetched Azure DevOps logs and embedded exact failure text, use that evidence.

Practical rule:

- If a backend finding cites CI behavior and `ci_checks.txt` contains the same failure text, keep that CI-backed claim unless the cloned code clearly disproves the alleged code location or interpretation.
- Only contradict a backend CI-backed finding after reading both `ci_checks.txt` and the cited repo lines.
- If `ci_checks.txt`, `pr.diff`, or the cloned code reveals an additional issue that is not already in the backend final review, add that finding using one of the backend severity labels and the same review structure.
- If the PR description or discussion thread reveals a concrete unresolved issue, incorrect assumption, or stale backend finding, reflect that in the final review, but only after tying it to current code, CI, docs, or runtime evidence.
- If a Databricks SQL probe or Databricks notebook probe reveals an additional issue that is not already in the backend final review, add that finding using one of the backend severity labels and the same review structure.
- If package-repo inspection shows that the reviewed code is using a dependency incorrectly, incompletely, or on an unnecessarily old version, add that to the final review with concrete evidence.
- If package-repo inspection reveals a package behavior change, only promote it to a finding when you can also show why that change matters for this repo specifically. Otherwise keep it as a recommendation or validation note, not a finding.
- If helper-repo inspection shows that the reviewed code is using `dlh-dmt-helper` incorrectly, incompletely, or on an unnecessarily old version, add that to the final review with concrete evidence.
- If helper-repo inspection reveals a package behavior change, only promote it to a finding when you can also show why that change matters for this repo specifically. Otherwise keep it as a recommendation or validation note, not a finding.
- If platform-doc or CI/CD-repo inspection reveals a deployment/runtime behavior, only promote it to a finding when you can also show why that behavior matters for this repo specifically. Otherwise keep it as a recommendation or validation note, not a finding.

When something is unclear, try to resolve it concretely before softening the review:

- If a CI-backed claim seems underspecified, inspect `ci_checks.txt`, `prompt_path`, `history.json`, and `stream_events.jsonl` before falling back to generic wording.
- If a claim depends on stated PR intent or comment-thread context, inspect `prompt_path` first and then `history.json` if you need to recover the exact wording or timeline.
- If a runtime claim depends on Databricks behavior, prefer a Databricks-backed probe over local Spark when it can be done safely.
- If a package-behavior claim is unclear, inspect the package's GitHub repo, changelog, tags, tests, and versioned files before assuming the answer is unavailable.
- If a helper-package claim is unclear, inspect `bi-dlh-helper` source, changelog, tags, tests, and versioned files before assuming the answer is unavailable.
- If a platform or deployment claim is unclear, inspect `bi-dlh-documentation` and `bi-dlh-dmt-ci-cd` before assuming the answer is unavailable.
- If a runtime-impact claim is unclear, inspect the reviewed repo for actual call sites, configs, operational docs, checklist expectations, and surrounding workflows before promoting the claim to a finding.
- If a file location or line range is unclear, read the cloned file directly and correct the citation rather than keeping an imprecise reference.

The goal is correctness, not agreement with the raw review.

### 7. Produce the final markdown review

Use the backend final review as the base document whenever it exists. Fall back to the initial review only if the final review is missing.

Always begin the final markdown with the PR link as the very first line so the user can open the PR directly from the top of the review, for example:

```markdown
**PR:** https://github.com/<owner>/<repo>/pull/<number>
```

Place this link above the review title/summary. Use the exact PR URL that was reviewed.

Before you finish writing, reconcile the internal finding ledger against the final markdown:

- Every `kept` finding must appear in the final review.
- Every omitted candidate must be explicitly `rejected` in your working notes before you finish.
- Do not let the final assistant message claim that findings were added, removed, or retained unless the saved markdown reflects that exactly.

- Preserve the overall structure, ordering, and tone unless a structural change is required to make the review correct.
- Correct inaccurate text in place.
- Remove unsupported findings instead of adding a visible "corrections" section.
- Add missed findings when they are concrete and evidenced, integrating them into the existing sections so the final document still reads as one coherent review.
- If removing or changing findings affects the summary, counts, or recommendations, update those parts too so the document stays internally consistent.
- Preserve the backend severity labels exactly. If a finding remains, its severity must be one of `CRITICAL`, `MAJOR`, `MINOR`, `SUGGESTION`.
- Do not reclassify a backend finding just because a different free-form label feels more natural. Only change severity when the backend severity is itself unsupported, and then map to one of the four allowed backend severities.
- Apply the same evidence standard to `### Summary`, `### Example Solutions`, `### Additional Recommendations`, and `### Overall Recommendation`, not just the findings table.
- If the correct remediation detail is unknown, say so generically instead of inventing a replacement symbol or parameter name.
- Example snippets may illustrate the type of change needed, but they must not pretend to know the exact new API unless that API is evidenced in the cloned repo, backend artifacts, or cited documentation.
- Runtime-sensitive wording must reflect what was actually executed. Do not present a Databricks runtime result as certain unless the result was executed in Databricks or otherwise proved from authoritative docs/source.
- When recommending package changes, prefer the latest package version and source-repo-supported usage patterns unless there is concrete evidence for an exception.
- When recommending `dlh-dmt-helper` changes, prefer the latest helper version and helper-repo-supported usage patterns unless there is concrete evidence for an exception.
- Do not turn a package-source migration possibility into a concrete code snippet unless the exact replacement parameters and semantics are evidenced in package source and map cleanly to the reviewed repo's actual call site.
- Do not turn a helper-source migration possibility into a concrete code snippet unless the exact replacement parameters and semantics are evidenced in helper source and map cleanly to the reviewed repo's actual call site.
- Do not mention the temp workspace, clone, helper scripts, backend startup, validation pass, or that the review was revised.
- Do not make it visible from the final markdown that the work happened in multiple steps.

Final coherence pass:

- Read the saved markdown once after the last edit.
- Confirm that the summary, findings/new-issues section, recommendations, and final user-facing summary all agree on the same set of findings.
- If the review format uses sections like `Previous Findings Status` and `New Issues`, make sure those sections agree with the actual findings present in the document.
- The final review must read like a single review with findings, not a review of the process used to produce it.
- Do not offer or ask about GitHub posting after the coherence pass. The review file on disk is the deliverable.

Write only the corrected final review to the output markdown file.

## GitHub Posting

**CRITICAL: Never post reviews to GitHub automatically. Never offer to post. Never ask whether to post. Only post when the user explicitly asks you to post a specific review.**

**This applies unconditionally — including when the skill is invoked from a polling loop, batch workflow, or any automated context. Being triggered automatically does NOT grant implicit permission to post. The deliverable is always the markdown file on disk, never a GitHub action.**

**Do not run `gh pr review`, `gh pr comment`, or any other `gh` command that writes to GitHub unless the user has explicitly said "post this review" (or equivalent) for the specific PR in question.**

The skill's job is to produce the final markdown file on disk. The user will decide if and when to post it themselves or ask you to do it.

When the user explicitly asks you to post a review:

- Default to posting as a formal PR review, not a plain PR comment.
- Default the review event from the final review recommendation:
  - If the final review recommendation is `REQUEST_CHANGES`, default to a request-changes review.
  - Otherwise, default to an approval review.
- Only use a plain PR comment when the user explicitly asks for a comment instead of a review.
- For a PR comment, use `gh pr comment <PR_URL> --body-file <FINAL_MARKDOWN_PATH>`.
- For a formal approval review, use `gh pr review <PR_URL> --approve --body-file <FINAL_MARKDOWN_PATH>`.
- For a formal request-changes review, use `gh pr review <PR_URL> --request-changes --body-file <FINAL_MARKDOWN_PATH>`.
- If the recommendation is neither explicit approval nor request changes, fall back to `gh pr review <PR_URL> --comment --body-file <FINAL_MARKDOWN_PATH>`.
- Prefer posting the exact final markdown file rather than reconstructing the body inline.
- Report the GitHub posting action back to the user, including whether it was posted as a comment or review and whether it succeeded.
- If `gh` auth or repository access fails, report the error and do not retry blindly.

## Review API Flag Mapping

Pass these flags to `run_review.py` only when the user explicitly asked for them:

- `model_key` -> `--model-key <value>`
- `max_tokens` -> `--max-tokens <int>`
- `prompt` -> `--prompt <text>`
- `reasoning_effort` -> `--reasoning-effort <value>`
- `thinking_level` -> `--thinking-level <int>`
- `excluded_files` -> repeat `--excluded-file <path>`
- explicit empty `excluded_files` -> `--clear-excluded-files`
- `enable_agent_tools` -> `--enable-agent-tools` or `--no-enable-agent-tools`
- `enable_ci_checks` -> `--enable-ci-checks` or `--no-enable-ci-checks`
- `enable_validation` -> `--enable-validation` or `--no-enable-validation`
- `enable_final_review` -> `--enable-final-review` or `--no-enable-final-review`
- `focus_changed_only` -> `--focus-changed-only` or `--no-focus-changed-only`
- `checklist_url` -> `--checklist-url <url>`
- `custom_instruction` -> `--custom-instruction <text>`
- `temperature` -> `--temperature <float>`
- `force_initial_review` -> `--force-initial-review` or `--no-force-initial-review`
- legacy `model_id` -> `--model-id <value>`
- legacy `max_tokens_setting` -> `--max-tokens-setting <int>`

## Failure Handling

- If backend discovery fails, retry with `--backend-root` or tell the user exactly what path needs to be provided.
- If the Python environment is wrong, rerun with `--python-executable` or set `PR_REVIEWER_PYTHON`.
- If GitHub access fails, surface the `gh` error instead of guessing.
- If Databricks execution is needed, load the `databricks` skill and follow its profile-selection rules instead of inventing a profile.
- If Databricks CLI is unavailable, say that clearly.
- If authentication is invalid or missing, initiate the Databricks CLI authentication workflow yourself and only ask the user for the missing host/profile choices when needed.
- If no safe profile/compute path exists even after attempting authentication, say that exact runtime validation could not be performed and keep the claim narrower.
- If a Databricks runtime probe fails, capture the exact command output in `<WORKSPACE>/databricks-validation/` and do not retry blindly against another profile or workspace.
- If CI evidence is disputed, inspect `ci_checks_path`, `validation_report_path`, `prompt_path`, and `history.json` before falling back to GitHub status metadata.
- If the raw reviewer produces no usable review, stop and report the failure. Do not fabricate the review.

## Output Rules

- Final deliverable: one markdown file containing the corrected review.
- Default location: current directory.
- Default filename: use `suggested_filename` from `pr-manifest.json` unless the user requested a different path.
- Keep the local review workspace so the raw artifacts remain inspectable.
- After writing each review file, fire a Windows toast notification so the user is alerted even when the terminal is in the background:
  ```bash
  powershell -ExecutionPolicy Bypass -File ~/.config/opencode/skills/review-pr/scripts/notify.ps1 -Title "PR Review Ready" -Message "Review written: <filename>"
  ```
  The notification script uses WinRT `ToastNotificationManager` and is located at `scripts/notify.ps1` (alongside the other bundled skill scripts).

## Polling Loop Behavior

When this skill is invoked from a polling loop (e.g., via `poll_reviews.py`):

- **No PRs found:** Wait 60 seconds before polling again.
- **After completing one or more reviews:** Poll again immediately with no wait. Reviews take well over 60 seconds, so adding another 60-second delay is unnecessary.

## Example

User request:

`Review https://github.com/org/repo/pull/123 with azure.gpt-5.2, disable CI checks, exclude uv.lock and poetry.lock, and save the final markdown in ./reviews/pr-123.md`

Execution pattern:

1. Create `./.review-pr-tmp/review-pr-<id>/`.
2. Run `run_review.py` with:
   - `--model-key azure.gpt-5.2`
   - `--no-enable-ci-checks`
   - `--excluded-file uv.lock`
   - `--excluded-file poetry.lock`
3. Run `clone_pr_head.py`.
4. Audit the raw review against the diff and cloned code.
5. Write the corrected markdown to `./reviews/pr-123.md`.
